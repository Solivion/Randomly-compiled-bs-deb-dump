// Copyright (c) 2020 OPEN CASCADE SAS
//
// This file is part of Open CASCADE Technology software library.
//
// This library is free software; you can redistribute it and/or modify it under
// the terms of the GNU Lesser General Public License version 2.1 as published
// by the Free Software Foundation, with special exception defined in the file
// OCCT_LGPL_EXCEPTION.txt. Consult the file LICENSE_LGPL_21.txt included in OCCT
// distribution for complete text of the license and disclaimer of any warranty.
//
// Alternatively, this file may be used under the terms of Open CASCADE
// commercial license or contractual agreement.

#ifndef _Aspect_Eye_HeaderFile
#define _Aspect_Eye_HeaderFile

//! Camera eye index within stereoscopic pair.
enum Aspect_Eye
{
  Aspect_Eye_Left,
  Aspect_Eye_Right
};

#endif // _Aspect_Eye_HeaderFile
