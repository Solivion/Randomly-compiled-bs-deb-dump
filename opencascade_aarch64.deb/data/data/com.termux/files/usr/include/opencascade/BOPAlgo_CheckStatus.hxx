// Created by: Peter KURNEV
// Copyright (c) 1999-2014 OPEN CASCADE SAS
//
// This file is part of Open CASCADE Technology software library.
//
// This library is free software; you can redistribute it and/or modify it under
// the terms of the GNU Lesser General Public License version 2.1 as published
// by the Free Software Foundation, with special exception defined in the file
// OCCT_LGPL_EXCEPTION.txt. Consult the file LICENSE_LGPL_21.txt included in OCCT
// distribution for complete text of the license and disclaimer of any warranty.
//
// Alternatively, this file may be used under the terms of Open CASCADE
// commercial license or contractual agreement.

#ifndef _BOPAlgo_CheckStatus_HeaderFile
#define _BOPAlgo_CheckStatus_HeaderFile

enum BOPAlgo_CheckStatus
{
  BOPAlgo_CheckUnknown,
  BOPAlgo_BadType,
  BOPAlgo_SelfIntersect,
  BOPAlgo_TooSmallEdge,
  BOPAlgo_NonRecoverableFace,
  BOPAlgo_IncompatibilityOfVertex,
  BOPAlgo_IncompatibilityOfEdge,
  BOPAlgo_IncompatibilityOfFace,
  BOPAlgo_OperationAborted,
  BOPAlgo_GeomAbs_C0,
  BOPAlgo_InvalidCurveOnSurface,
  BOPAlgo_NotValid
};

#endif // _BOPAlgo_CheckStatus_HeaderFile
