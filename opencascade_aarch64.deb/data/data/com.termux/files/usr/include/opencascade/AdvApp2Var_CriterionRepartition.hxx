// Created on: 1996-03-05
// Created by: Joelle CHAUVET
// Copyright (c) 1996-1999 Matra Datavision
// Copyright (c) 1999-2014 OPEN CASCADE SAS
//
// This file is part of Open CASCADE Technology software library.
//
// This library is free software; you can redistribute it and/or modify it under
// the terms of the GNU Lesser General Public License version 2.1 as published
// by the Free Software Foundation, with special exception defined in the file
// OCCT_LGPL_EXCEPTION.txt. Consult the file LICENSE_LGPL_21.txt included in OCCT
// distribution for complete text of the license and disclaimer of any warranty.
//
// Alternatively, this file may be used under the terms of Open CASCADE
// commercial license or contractual agreement.

#ifndef _AdvApp2Var_CriterionRepartition_HeaderFile
#define _AdvApp2Var_CriterionRepartition_HeaderFile

//! way of cutting process//! all new cutting points at each step of cutting
//! process : (a+i(b-a)/N)i at step N,
//! (a+i(b-a)/(N+1))i at step N+1,...
//! where (a,b) is the global interval//! add one new cutting point at each step
//! of cutting process
enum AdvApp2Var_CriterionRepartition
{
  AdvApp2Var_Regular,
  AdvApp2Var_Incremental
};

#endif // _AdvApp2Var_CriterionRepartition_HeaderFile
