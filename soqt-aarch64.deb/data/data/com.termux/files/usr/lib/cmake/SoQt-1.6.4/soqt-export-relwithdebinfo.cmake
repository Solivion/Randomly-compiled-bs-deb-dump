#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SoQt::SoQt" for configuration "RelWithDebInfo"
set_property(TARGET SoQt::SoQt APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SoQt::SoQt PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libSoQt.so.20.6.4"
  IMPORTED_SONAME_RELWITHDEBINFO "libSoQt.so.20"
  )

list(APPEND _cmake_import_check_targets SoQt::SoQt )
list(APPEND _cmake_import_check_files_for_SoQt::SoQt "${_IMPORT_PREFIX}/lib/libSoQt.so.20.6.4" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
