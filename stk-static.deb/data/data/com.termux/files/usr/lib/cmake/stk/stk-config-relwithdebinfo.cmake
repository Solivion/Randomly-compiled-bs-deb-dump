#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "stk" for configuration "RelWithDebInfo"
set_property(TARGET stk APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(stk PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libstk.a"
  )

list(APPEND _cmake_import_check_targets stk )
list(APPEND _cmake_import_check_files_for_stk "${_IMPORT_PREFIX}/lib/libstk.a" )

# Import target "stk_SHARED" for configuration "RelWithDebInfo"
set_property(TARGET stk_SHARED APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(stk_SHARED PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libstk.so"
  IMPORTED_SONAME_RELWITHDEBINFO "libstk.so"
  )

list(APPEND _cmake_import_check_targets stk_SHARED )
list(APPEND _cmake_import_check_files_for_stk_SHARED "${_IMPORT_PREFIX}/lib/libstk.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
